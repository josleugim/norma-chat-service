# Archivo del repo: agent/turn_state.py
# Copiado tal cual para esta corrida.

"""
Estado de un turno del agente.

Existe por dos razones:

1. **Concurrencia.** El agente es un singleton en `app.state`, así que guardar
   estado del turno en `self.*` hacía que dos peticiones simultáneas se
   pisaran: los expedientes de un usuario podían acabar en la respuesta de
   otro. Todo lo que dura un turno vive aquí y se crea por petición.

2. **Trazabilidad de citas.** El registro de citas tiene que acompañar al turno
   completo —desde que se recupera un documento hasta que se muestra la
   fuente— y ese es exactamente el alcance de este objeto.
"""
from dataclasses import dataclass, field

from core.citations import CitationRegistry


@dataclass
class TurnState:
    # Identificadores estables de cita para este turno
    registry: CitationRegistry = field(default_factory=CitationRegistry)

    # Últimos expedientes recuperados. Permite que calcular_plazos opere sobre
    # ellos sin que el modelo tenga que devolverlos, que es lo que truncaba
    # sus argumentos contra el límite de tokens.
    last_expedientes: list[dict] = field(default_factory=list)

    # Cobertura de la última búsqueda
    universo_completo: bool = False
    universo_tamano: int = 0

    # Filtro local que no coincidió con nada, para poder distinguir
    # "no hay ninguno" de "tu filtro estaba mal escrito"
    filtro_vacio: dict | None = None

    # ── Routing y control de suficiencia ────────────────────
    # La secuencia que pidió COFECE para v1, sin reranker ni multiagente:
    #   routing → evidence check → un retry focalizado → abstención
    query: str = ""
    query_type: str = ""
    sufficiency_checks: list[dict] = field(default_factory=list)
    retrieval_retries: int = 0
    pending_retry_terms: list[str] = field(default_factory=list)
    abstention_reason: str | None = None

    # ── Linaje de filtros ───────────────────────────────────
    # Mientras la API una con OR en vez de intersectar, hay que poder ver
    # filtros pedidos → resultados de la API → postfiltro local → universo
    # final, con cuántos descartó cada condición.
    filtros_aplicados: list[dict] = field(default_factory=list)

    # ── Auditoría de cálculos deterministas ─────────────────
    # Un registro por expediente y operación, para poder reconstruir un
    # promedio o un máximo desde los artifacts sin releer el código.
    computation_audit: list[dict] = field(default_factory=list)
    # Anomalías de datos encontradas, en formato analizable.
    anomalias: list[dict] = field(default_factory=list)

    # ── Composición de la evidencia ─────────────────────────
    # Cuántas resoluciones de la autoridad de competencia y cuántas sentencias
    # del poder judicial entraron al contexto. Sin esto, una respuesta sobre
    # "los criterios de la COFECE" construida con 17 sentencias de 60 fuentes
    # se ve idéntica a una construida sólo con resoluciones.
    composicion_fuentes: dict | None = None

    # ── Rutas de búsqueda ejercidas en el turno ─────────────
    # Cuántos resultados devolvió cada herramienta de recuperación. Sirve para
    # una sola pregunta, que es la que q14 contestó mal: ¿se puede afirmar que
    # algo NO existe?
    #
    # Ante "¿qué precedentes hay en el mercado de distribución de
    # medicamentos?" el agente hizo UNA búsqueda léxica sobre metadatos, recibió
    # cero, y afirmó que no existen precedentes — sin consultar nunca el índice
    # semántico de criterios, que es donde vivirían. La respuesta resultó
    # correcta, y eso es lo que la hace peligrosa: falsa exhaustividad
    # acertando por suerte, igual que el filtro de negación de §24.6.
    resultados_por_herramienta: dict[str, int] = field(default_factory=dict)
