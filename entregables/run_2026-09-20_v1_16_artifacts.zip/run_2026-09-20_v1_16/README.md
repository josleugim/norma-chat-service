# Corrida run_2026-09-20_v1_16

PR3: atribucion de fuentes · 20 preguntas · generado el 2026-09-20

Paquete autocontenido: resultados, trazas, prompts, herramientas y el código
exacto con el que corrió. La idea es poder diagnosticar sin tener que
reconstruir el estado del repo.

## Qué hay aquí

| Carpeta | Qué contiene |
|---|---|
| `manifest.json` | Versiones congeladas, commit, censo del acervo, drift |
| `results/` | Resumen por pregunta, tabla para analizar y evaluación automática |
| `traces/` | Una traza completa por consulta, con el retrieval crudo |
| `prompts/` | El prompt del sistema tal como se usó |
| `agent_code/` | Routing, suficiencia, agente, citas, agregaciones |
| `tools/` | Definición de herramientas, cálculo de plazos, clientes de datos |
| `retrieval_config/` | top-k, thresholds, truncado y notas del pipeline |
| `errors_warnings/` | Errores, anomalías de datos y drift, en texto legible |

## Baseline de esta corrida

- **Commit del agente:** `d34b216`
- **Prompt:** `5ca8d04c2f86`
- **Herramientas:** `3a1aeb821160`
- **Calendario de días inhábiles:** `fee758a0ac16`
- **Acervo al arrancar:** 4697 expedientes {'VCN': 38, 'IO': 1, 'CNT': 4617, 'DE': 0, 'RA': 0, 'CON': 0, 'JUDICIAL/OTRO': 41}

## Por dónde empezar

1. `results/tabla.xlsx` — una fila por pregunta. Las columnas `diagnosis_stage`
   y `diagnosis_reason` dicen en qué etapa se rompió el flujo.
2. Para una respuesta concreta, abre `traces/<trace_id>.json`: trae la
   interpretación, cada búsqueda con sus filtros, las tres etapas de retrieval,
   las herramientas con sus parámetros y resultados, y el registro de citas.
3. `errors_warnings/resumen.md` — anomalías de datos y cobertura.

## Limitaciones que conviene tener presentes

- **No se puede versionar el índice ni el modelo de embeddings**: la API no los
  expone. Cada traza lo declara en `versions.unknown`. Si el índice cambió
  durante la corrida, no lo detectaríamos; el censo del acervo en el manifiesto
  es un sustituto parcial.
- **No hay reranker** en el pipeline. Ver `retrieval_config/parametros.json`.
- El paquete **no incluye credenciales** por diseño.
