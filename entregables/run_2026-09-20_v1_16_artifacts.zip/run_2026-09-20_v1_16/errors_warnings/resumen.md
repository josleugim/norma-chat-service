# Errores, anomalías y advertencias de la corrida

## Baseline drift

Ninguno: el entorno no cambió durante la corrida.

## Turnos con error

Ninguno.

## Anomalías de datos

- **fecha_fin_anterior_a_inicio**: 61 casos. Ejemplos: CNT-003-2025, CNT-004-2024-I, CNT-008-2025, CNT-011-2025, CNT-013-2025, CNT-014-2025, CNT-016-2025, CNT-021-2025, CNT-037-2025, CNT-044-2024-I

- **fecha_fuera_del_calendario**: 15 casos. Ejemplos: CNT-061-2013, CNT-064-2013, CNT-074-2013, CNT-080-2013, CNT-081-2013, CNT-083-2013, CNT-084-2013, CNT-085-2013, CNT-086-2013, CNT-087-2013

- **fecha_inicio_igual_a_fin**: 52 casos. Ejemplos: CNT-004-2025, CNT-006-2025, CNT-007-2025, CNT-010-2025, CNT-017-2025, CNT-020-2025, CNT-022-2025, CNT-023-2025, CNT-045-2024, CNT-049-2024

## Consultas exhaustivas resueltas sobre universo truncado

- q10: ¿cuáles son los criterios que usa la COFECE para determinar el monto de las multas?
